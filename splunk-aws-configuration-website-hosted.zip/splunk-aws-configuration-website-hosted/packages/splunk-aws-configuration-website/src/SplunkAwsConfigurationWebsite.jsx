import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Heading from '@splunk/react-ui/Heading';
import Menu from '@splunk/react-ui/Menu';
import P from '@splunk/react-ui/Paragraph';
import Button from '@splunk/react-ui/Button';
import { includes, without } from 'lodash';
import Switch from '@splunk/react-ui/Switch';
import { Splunk, Enterprise, Light, Cloud, Hunk } from '@splunk/react-ui/Logo'
import Text from '@splunk/react-ui/Text';
import css from './SplunkAwsConfigurationWebsite.css';
import ControlGroup from '@splunk/react-ui/ControlGroup';
import Multiselect from '@splunk/react-ui/Multiselect';
import { createDOMID } from '@splunk/ui-utils/id';
import FormRows from '@splunk/react-ui/FormRows';


class SplunkAwsConfigurationWebsite extends Component {
    static propTypes = {
        name: PropTypes.string,
    };

    static defaultProps = {
        name: 'AWS to Splunk logging configuration',
    };

    constructor(props) {
        super(props);
        // Toggles visibility for certain items through display css styling
        let dynamicValues = {'AWS Config Notifications': '', 'AWS Config Snapshots': 'none', 'AWS CloudTrail': '', 'AWS VPC Flow logs': 'none', 'AWS CloudWatch logs': 'none', 'HECToken': '', 'EndpointField': '', 'EndpointValue': '' };
        // First rows in the FormRows objects
        const vpcRows = [
            <FormRows.Row index={0} key="0" onRequestRemove={this.handleRequestVPCRowRemove}>
                <Text placeholder="VPC Flow log group name (including prefix)" name={0} onChange={this.handleVPCChange} />
            </FormRows.Row>,
        ];
        const cloudwatchRows = [
            <FormRows.Row index={0} key="0" onRequestRemove={this.handleRequestCloudWatchRowRemove}>
                <Text canClear placeholder="CloudWatch log group name (including prefix)" name={0} onChange={this.handleCWLChange} />
            </FormRows.Row>,
        ];
        this.state = {
            // The FormRows objects for VPC Flow logs and CloudWatch logs
            vpcRows,
            cloudwatchRows,

            // Main object containing AWS Service selection metadata
            items: [
                { id: 1, title: 'AWS Config Notifications', done: true, display: dynamicValues['AWS Config Notifications'] },
                { id: 2, title: 'AWS Config Snapshots', done: false, display: dynamicValues['AWS Config Snapshots'] },
                { id: 3, title: 'AWS CloudTrail', done: true, display: dynamicValues['AWS CloudTrail'] },
                { id: 4, title: 'AWS VPC Flow logs', done: false, display: dynamicValues['AWS VPC Flow logs']},
                { id: 5, title: 'AWS CloudWatch logs', done: false, display: dynamicValues['AWS CloudWatch logs']},
                { id: 6, title: 'AWS CloudWatch Events', done: true, display: dynamicValues['AWS CloudWatch Events'] },
            ],
            // The values object contains a list of all selected CloudWatch Events
            values: [],

            // The cwlGroups and vpcGroups hold the ACTUAL user input to the form rows. For some reason the user input
            // is not visible in the FormRows object and most be stored externally. Format: ["foo", "bar"]
            cwlGroups: [],
            vpcGroups: [],

            // Splunk HEC Token with indexer ack enabled
            TokenValue: '',
            // Splunk HEC Token with no indexer ack enabled
            NoAckTokenValue: '',

            // Toggles display of the the HEC token entry fields
            TokenDisplay: '',
            NoAckTokenDisplay: '',

            // Boolean for user selection of automatic HEC token creation
            autoHEC: false,

            // Splunk endpoint related fields
            SplunkManagementEndpoint: '',
            SplunkCredentialsDisplay: 'none',

            EndpointField: dynamicValues["EndpointField"],
            EndpointValue: dynamicValues["EndpointValue"],

            /*
                A list of objects describing AWS services/CloudWatch Events
                Format: {
                            name: "Name of AWS services/CloudWatch Event",
                            type: "Either 'event' or 'service' depending on if it is an CloudWatch Event name or an AWS Service"
                        }
            */
            cwe_full_list: [
                {name: "Batch", type: "service"}, {name: "Batch Job State Change", type: "event"}, {name: "AutoScaling", type: "service"}, {name: "EC2 Instance Launch Successful", type: "event"}, {name: "EC2 Instance Terminate Successful", type: "event"}, {name: "EC2 Instance Launch Unsuccessful", type: "event"}, {name: "EC2 Instance Terminate Unsuccessful", type: "event"}, {name: "EC2 Instance-launch Lifecycle Action", type: "event"}, {name: "EC2 Instance-terminate Lifecycle Action", type: "event"}, {name: "CloudWatch", type: "service"}, {name: "CloudWatch Events Scheduled Event", type: "event"}, {name: "CodeBuild", type: "service"}, {name: "CodeBuild Build State Change", type: "event"}, {name: "CodeBuild Build Phase Change", type: "event"}, {name: "CodeCommit", type: "service"}, {name: "CodeCommit Repository State Change", type: "event"}, {name: "CodeCommit Comment on Commit", type: "event"}, {name: "CodeCommit Comment on Pull Request", type: "event"}, {name: "CodeDeploy", type: "service"}, {name: "CodeDeploy Deployment State-change Notification", type: "event"}, {name: "CodeDeploy Instance State-change Notification", type: "event"}, {name: "CodePipeline", type: "service"}, {name: "CodePipeline Pipeline Execution State Change", type: "event"}, {name: "CodePipeline Stage Execution State Change", type: "event"}, {name: "CodePipeline Action Execution State Change", type: "event"}, {name: "Config", type: "service"}, /*{name: "Config Configuration Item Change", type: "event"},*/ {name: "Config Rules Compliance Change", type: "event"}, {name: "Config Rules Re-evaluation Status", type: "event"}, {name: "Config Configuration Snapshot Delivery Status", type: "event"}, {name: "Config Configuration History Delivery Status", type: "event"}, {name: "Data Lifecycle Manager", type: "service"}, {name: "DLM Policy State Change", type: "event"}, {name: "EC2", type: "service"}, {name: "EC2 Instance State-change Notification", type: "event"}, {name: "EBS Volume Notification", type: "event"}, {name: "EBS Snapshot Notification", type: "event"}, {name: "EC2 Spot Instance Interruption Warning", type: "event"}, {name: "EC2 Container Service (ECS)", type: "service"}, {name: "ECS Task State Change", type: "event"}, {name: "ECS Container Instance State Change", type: "event"}, {name: "EC2 Simple Systems Manager (SSM)", type: "service"}, {name: "EC2 State Manager Association State Change", type: "event"}, {name: "EC2 State Manager Instance Association State Change", type: "event"}, {name: "EC2 Command Status-change Notification", type: "event"}, {name: "EC2 Command Invocation Status-change Notification", type: "event"}, {name: "Maintenance Window State-change Notification", type: "event"}, {name: "Maintenance Window Target Registration Notification", type: "event"}, {name: "Maintenance Window Execution State-change Notification", type: "event"}, {name: "Maintenance Window Task Execution State-change Notification", type: "event"}, {name: "Maintenance Window Task Target Invocation State-change Notification", type: "event"}, {name: "Maintenance Window Task Registration Notification", type: "event"}, {name: "EC2 Automation Step Status-change Notification", type: "event"}, {name: "EC2 Automation Execution Status-change Notification", type: "event"}, {name: "Parameter Store Change", type: "event"}, {name: "Configuration Compliance State Change", type: "event"}, {name: "Inventory Resource State Change", type: "event"}, {name: "EMR", type: "service"}, {name: "EMR Auto Scaling Policy State Change", type: "event"}, {name: "EMR Step Status Change", type: "event"}, {name: "EMR Cluster State Change", type: "event"}, {name: "EMR Instance Group State Change", type: "event"}, {name: "EMR Instance Fleet State Change", type: "event"}, {name: "EMR Instance Group Status Notification", type: "event"}, {name: "GameLift", type: "service"}, {name: "GameLift Matchmaking Event", type: "event"}, {name: "Glue", type: "service"}, {name: "Glue Job State Change", type: "event"}, {name: "Glue Crawler State Change", type: "event"}, {name: "Glue Job Run Status", type: "event"}, {name: "GuardDuty", type: "service"},  {name: "GuardDuty Finding", type: "event"}, {name: "Health", type: "service"}, {name: "AWS Health Event", type: "event"}, {name: "Key Management Service (KMS)", type: "service"}, {name: "KMS Imported Key Material Expiration", type: "event"}, {name: "KMS CMK Rotation", type: "event"}, {name: "KMS CMK Deletion", type: "event"}, {name: "Macie", type: "service"}, {name: "Macie Alert", type: "event"}, {name: "MediaConvert", type: "service"}, {name: "MediaConvert Job State Change", type: "event"}, {name: "MediaLive", type: "service"}, {name: "MediaLive Channel State Change", type: "event"}, {name: "MediaLive Channel Alert", type: "event"}, {name: "MediaStore", type: "service"}, {name: "MediaStore Object State Change", type: "event"}, {name: "MediaStore Container State Change", type: "event"}, {name: "OpsWorks", type: "service"}, {name: "OpsWorks Instance State Change", type: "event"}, {name: "OpsWorks Command State Change", type: "event"}, {name: "OpsWorks Deployment State Change", type: "event"}, {name: "OpsWorks Alert", type: "event"}, {name: "Security Hub", type: "service"}, {name: "Security Hub Findings - Imported", type: "event"}, {name: "Security Hub Insight Results", type: "event"}, {name: "Security Hub Findings - Custom Action", type: "event"}, {name: "Server Migration Service (SMS)", type: "service"}, {name: "Server Migration Job State Change", type: "event"}, {name: "Signer", type: "service"}, {name: "Signer Job Status Change", type: "event"}, {name: "Storage Gateway", type: "service"}, {name: "Storage Gateway File Upload Event", type: "event"}, {name: "Storage Gateway Refresh Cache Event", type: "event"}, {name: "Transcribe", type: "service"}, {name: "Transcribe Job State Change", type: "event"}, {name: "WorkSpaces", type: "service"}, {name: "WorkSpaces Access", type: "event"}
            ],

            // A mapping of all CloudWatch Events to the AWS service they come from
            cwe_event_service_map: {
                "Batch Job State Change": "aws.batch", "EC2 Instance Launch Successful": "aws.autoscaling", "EC2 Instance Terminate Successful": "aws.autoscaling", "EC2 Instance Launch Unsuccessful": "aws.autoscaling", "EC2 Instance Terminate Unsuccessful": "aws.autoscaling", "EC2 Instance-launch Lifecycle Action": "aws.autoscaling", "EC2 Instance-terminate Lifecycle Action": "aws.autoscaling", "CloudWatch Events Scheduled Event": "aws.cloudwatch", "CodeBuild Build State Change": "aws.codebuild", "CodeBuild Build Phase Change": "aws.codebuild", "CodeCommit Repository State Change": "aws.codecommit", "CodeCommit Comment on Commit": "aws.codecommit", "CodeCommit Comment on Pull Request": "aws.codecommit", "CodeDeploy Deployment State-change Notification": "aws.codedeploy", "CodeDeploy Instance State-change Notification": "aws.codedeploy", "CodePipeline Pipeline Execution State Change": "aws.codepipline", "CodePipeline Stage Execution State Change": "aws.codepipeline", "CodePipeline Action Execution State Change": "aws.codepipeline", /*"Config Configuration Item Change": "aws.config",*/"Config Rules Compliance Change": "aws.config", "Config Rules Re-evaluation Status": "aws.config", "Config Configuration Snapshot Delivery Status": "aws.config", "Config Configuration History Delivery Status": "aws.config", "DLM Policy State Change": "aws.dlm", "EC2 Instance State-change Notification": "aws.ec2", "EBS Volume Notification": "aws.ec2", "EBS Snapshot Notification": "aws.ec2", "EC2 Spot Instance Interruption Warning": "aws.ec2", "ECS Task State Change": "aws.ecs", "ECS Container Instance State Change": "aws.ecs", "EC2 State Manager Association State Change": "aws.ssm", "EC2 State Manager Instance Association State Change": "aws.ssm", "EC2 Command Status-change Notification": "aws.ssm", "EC2 Command Invocation Status-change Notification": "aws.ssm", "Maintenance Window State-change Notification": "aws.ssm", "Maintenance Window Target Registration Notification": "aws.ssm", "Maintenance Window Execution State-change Notification": "aws.ssm", "Maintenance Window Task Execution State-change Notification": "aws.ssm", "Maintenance Window Task Target Invocation State-change Notification": "aws.ssm", "Maintenance Window Task Registration Notification": "aws.ssm", "EC2 Automation Step Status-change Notification": "aws.ssm", "EC2 Automation Execution Status-change Notification": "aws.ssm", "Parameter Store Change": "aws.ssm", "Configuration Compliance State Change": "aws.ssm", "Inventory Resource State Change": "aws.ssm", "EMR Auto Scaling Policy State Change": "aws.emr", "EMR Step Status Change": "aws.emr", "EMR Cluster State Change": "aws.emr", "EMR Instance Group State Change": "aws.emr", "EMR Instance Fleet State Change": "aws.emr", "EMR Instance Group Status Notification": "aws.emr", "GameLift Matchmaking Event": "aws.gamelift", "Glue Job State Change": "aws.glue", "Glue Crawler State Change": "aws.glue", "Glue Job Run Status": "aws.glue", "GuardDuty Finding": "aws.guardduty", "Security Hub Findings - Imported": "aws.securityhub", "Security Hub Insight Results": "aws.securityhub", "Security Hub Findings - Custom Action": "aws.securityhub", "AWS Health Event": "aws.health", "KMS Imported Key Material Expiration": "aws.kms", "KMS CMK Rotation": "aws.kms", "KMS CMK Deletion": "aws.kms", "Macie Alert": "aws.macie", "MediaConvert Job State Change": "aws.mediaconvert", "MediaLive Channel State Change": "aws.medialive", "MediaLive Channel Alert": "aws.medialive", "MediaStore Object State Change": "aws.mediastore", "MediaStore Container State Change": "aws.mediastore", "OpsWorks Instance State Change": "aws.opsworks", "OpsWorks Command State Change": "aws.opsworks", "OpsWorks Deployment State Change": "aws.opsworks", "OpsWorks Alert": "aws.opsworks", "Server Migration Job State Change": "aws.sms", "Signer Job Status Change": "aws.signer", "Storage Gateway File Upload Event": "aws.storagegateway", "Storage Gateway Refresh Cache Event": "aws.storagegateway", "Transcribe Job State Change": "aws.transcribe", "WorkSpaces Access": "aws.workspaces"
            }
        };
    }

    render() {
        return (
            <div className={css.main}>
                <div className={css.container}>
                    <Heading level={1} style={{ "textAlign": 'center', "color": "#5cc05c" }}>{this.props.name}</Heading>
                    <br/>
                    <P style={{ "width": "90%", "textAlign": 'center', "margin": "0 auto" }}>
                        Use the following form to create a unique AWS CloudFormation template that will forward logs from your AWS environment to Splunk.
                        Once you have selected all your data sources, download the AWS CloudFormation template and deploy it using the AWS CLI or AWS CloudFormation console.
                    </P>
                    <br/>
                    <P style={{ "width": "90%", "textAlign": 'center', "margin": "0 auto" }}>
                        <b>General configuration</b>
                    </P>
                    <P style={{ "width": "90%", "textAlign": 'center', "margin": "0 auto" }}>
                        Provide general details about your AWS and Splunk environment
                    </P>
                    <br/>
                    <ControlGroup
                        label="Splunk endpoint URL and port"
                        labelPosition="top"
                        tooltip="Format is https://{{server}}:{{port}}. The default port for HTTP Event Collector is 8088 (For Splunk Cloud endpoints, the default is 443). This endpoint should have a valid SSL certificate installed for the port."
                        help="Example: https://1.1.1.1:8088"
                        style={{ "margin": '0 auto', "display": this.state.EndpointField }}
                    >
                        <Text canClear onChange={this.handleEndpointChange} style={{ "width": "30%", "textAlign": 'center' }}/>
                    </ControlGroup>
                     <br/>
                    <ControlGroup
                        label="Automatically generate the required HTTP Event Collector tokens on your Splunk environment"
                        labelPosition="top"
                        style={{ "margin": '0 auto' }}
                    >
                     <Switch
                         key={0}
                         value='unused'
                         onClick={() => this.handleAutoHecClick(0)}
                         selected={this.state.autoHEC}
                         appearance="toggle"
                     >
                     </Switch>
                    </ControlGroup>
                    <br/>
                    <ControlGroup
                        label="Splunk management endpoint URL and port"
                        labelPosition="top"
                        tooltip="Format is https://{{server}}:{{port}}. The default management port for Splunk is 8089."
                        help="Example: https://1.1.1.1:8089"
                        style={{ "margin": '0 auto', "display": this.state.SplunkCredentialsDisplay }}
                    >
                        <Text canClear onChange={this.handleMgmtEndpointChange} style={{ "width": "30%", "textAlign": 'center' }}/>
                    </ControlGroup>
                    <ControlGroup
                        label="HTTP Event Collector Token (Indexer acknowledgement enabled)"
                        labelPosition="top"
                        tooltip="Format is 12345678-qwer-asdf-zxcv-123456789qwe. Confirm that the token is enabled and indexer acknowledgement is enabled"
                        help="For example: 12345678-qwer-asdf-zxcv-123456789qwe"
                        style={{ "margin": '0 auto', "display": this.state.TokenDisplay }}
                    >
                        <Text inline onChange={this.handleTokenChange} canClear/>
                    </ControlGroup>
                    <br/>
                    <ControlGroup
                        label="HTTP Event Collector Token (Indexer acknowledgement disabled)"
                        labelPosition="top"
                        tooltip="Format is 12345678-qwer-asdf-zxcv-123456789qwe. Confirm that the token is enabled and indexer acknowledgement is disabled."
                        help="For example: 12345678-qwer-asdf-zxcv-123456789qwe. Only required for the AWS Config Snapshots data source."
                        style={{ "margin": '0 auto', "display": this.state.items[1].display === '' && this.state.NoAckTokenDisplay === '' ? '' : 'none' }}
                    >
                        <Text inline onChange={this.handleNoAckTokenChange} canClear/>
                    </ControlGroup>
                    <br/>
                    <P style={{ "width": "90%", "textAlign": 'center', "margin": "0 auto" }}>
                        <b>AWS data source configuration</b>
                    </P>
                    <P style={{ "width": "90%", "textAlign": 'center', "margin": "0 auto" }}>
                        Select the AWS data sources which will be sent to Splunk
                    </P>
                    <br/>
                    <div style={{ "margin": "0 auto", "width": "750px" }}>
                        <Menu>
                            <Menu.Item
                                selectable
                                selected={this.state.items[0].done}
                                key={this.state.items[0].id}
                                style={{ "width": "700px", "margin": "0 auto", "float": "left" }}
                            >
                                {this.state.items[0].title}
                                <Switch
                                    key={this.state.items[0].id}
                                    value={this.state.items[0].title}
                                    onClick={() => this.handleToggleClick(0)}
                                    selected={this.state.items[0].done}
                                    appearance="toggle"
                                    style={{ "float": "right", "marginTop": "-5px" }}
                                />
                            </Menu.Item>
                            <br/>
                            <Menu.Item
                                selectable
                                selected={this.state.items[1].done}
                                key={this.state.items[1].id}
                                style={{ "width": "700px", "margin": "0 auto", "float": "left" }}
                            >
                                {this.state.items[1].title}
                                <Switch
                                    key={this.state.items[1].id}
                                    value={this.state.items[1].title}
                                    onClick={() => this.handleToggleClick(1)}
                                    selected={this.state.items[1].done}
                                    appearance="toggle"
                                    style={{ "float": "right", "marginTop": "-5px" }}
                                />
                            </Menu.Item>
                            <br/>
                            <Menu.Item
                                selectable
                                selected={this.state.items[2].done}
                                key={this.state.items[2].id}
                                style={{ "width": "700px", "margin": "0 auto", "float": "left" }}
                            >
                                {this.state.items[2].title}
                               <Switch
                                    key={this.state.items[2].id}
                                    value={this.state.items[2].title}
                                    onClick={() => this.handleToggleClick(2)}
                                    selected={this.state.items[2].done}
                                    appearance="toggle"
                                    style={{ "float": "right", "marginTop": "-5px" }}
                                />
                            </Menu.Item>
                            <br/>
                            <Menu.Item
                                selectable
                                selected={this.state.items[3].done}
                                key={this.state.items[3].id}
                                style={{ "width": "700px", "margin": "0 auto", "float": "left" }}
                            >
                                {this.state.items[3].title}
                                <FormRows
                                    onRequestAdd={this.handleRequestVPCRowAdd}
                                    onRequestMove={this.handleRequestVPCRowMove}
                                    style={{ width: 400, "display": this.state.items[3].display, "marginLeft": "200px",  "marginTop": "-20px" }}
                                >
                                    {this.state.vpcRows}
                                </FormRows>
                                <Switch
                                    key={this.state.items[3].id}
                                    value={this.state.items[3].title}
                                    onClick={() => this.handleToggleClick(3)}
                                    selected={this.state.items[3].done}
                                    appearance="toggle"
                                    style={{ "float": "right" }}
                                />
                            </Menu.Item>
                            <br/>
                            <Menu.Item
                                selectable
                                selected={this.state.items[4].done}
                                key={this.state.items[4].id}
                                style={{ "width": "700px", "margin": "0 auto", "float": "left" }}
                            >
                                {this.state.items[4].title}
                                <FormRows
                                    onRequestAdd={this.handleRequestCloudWatchRowAdd}
                                    onRequestMove={this.handleRequestCloudWatchRowMove}
                                    style={{ width: 400,  "display": this.state.items[4].display, "marginLeft": "200px",  "marginTop": "-20px" }}

                                >
                                    {this.state.cloudwatchRows}
                                </FormRows>
                                <Switch
                                    key={this.state.items[4].id}
                                    value={this.state.items[4].title}
                                    onClick={() => this.handleToggleClick(4)}
                                    selected={this.state.items[4].done}
                                    appearance="toggle"
                                    style={{ "float": "right" }}
                                />
                            </Menu.Item>
                            <br/>
                            <Menu.Item
                                selectable
                                selected={this.state.items[5].done}
                                key={this.state.items[5].id}
                                style={{ "width": "700px", "margin": "0 auto", "float": "left" }}
                            >
                                {this.state.items[5].title}
                                <Multiselect
                                    values={this.state.values}
                                    onChange={this.handleCWEChange}
                                    style={{ "marginLeft": "40px", "display": this.state.items[5].display }}
                                    inline
                                >
                                    {this.state.cwe_full_list.map((item) =>
                                        {if (item.type === "event") {
                                            return(
                                                <Multiselect.Option label={item.name} value={item.name } />
                                            )
                                        }
                                        if (item.type === "service") {
                                            return(<Multiselect.Heading>{item.name}</Multiselect.Heading>)
                                        }}
                                    )}
                                </Multiselect>
                                <Switch
                                    key={this.state.items[5].id}
                                    value={this.state.items[5].title}
                                    onClick={() => this.handleToggleClick(5)}
                                    selected={this.state.items[5].done}
                                    appearance="toggle"
                                    style={{ "float": "right", "marginTop": "-5px" }}
                                />
                            </Menu.Item>
                        </Menu>
                    </div>
                    <br/>
                    <Button label="Download CloudFormation template" onClick={() => this.handleDownloadClick()} appearance="primary" style={{ flexBasis: '200px' }} />
                    <br/>
                    <div className={css.container}>
                        <Heading level={2} style={{ textAlign: 'center' }}>
                            Legal
                        </Heading>
                        <Heading level={3} style={{ textAlign: 'center' }}>
                            This automation template generating tool is not supported by Splunk.
                        </Heading>
                        <P style={{ textAlign: 'left' }}>
                            THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
                        </P>
                    </div>
                </div>
            </div>
        );
    }

    handleRequestVPCRowAdd = () => {
          /*
            Adds an empty row to the vpcRows object
         */
        this.setState({
            vpcRows: FormRows.addRow(
                <FormRows.Row
                    index={this.state.vpcRows.length}
                    key={createDOMID()}
                    onRequestRemove={this.handleRequestVPCRowRemove}
                >
                    <Text placeholder="VPC Flow log group name (including prefix)" name={this.state.vpcGroups.length} onChange={this.handleCWLChange} />
                </FormRows.Row>,
                this.state.vpcRows
            ),
        });
    };

    handleRequestVPCRowMove = ({ fromIndex, toIndex }) => {
        /*
            Moves a row in the vpcRows object.
            Also handles the movement of the row user input in the vpcGroups object.
         */
        let vpcGroups = this.state.vpcGroups;
        let tmp = vpcGroups[toIndex];
        vpcGroups[toIndex] = vpcGroups[fromIndex];
        vpcGroups[fromIndex] = tmp;

        this.setState({ vpcGroups });

        this.setState({
            vpcRows: FormRows.moveRow(fromIndex, toIndex, this.state.vpcRows),
        });
    };

    handleRequestVPCRowRemove = (e, { index }) => {
        /*
            Deletes a row in the vpcRows object.
            Also handles the deletion of the row user input in the vpcGroups object.
         */
        let vpcGroups = this.state.vpcGroups;
        vpcGroups.splice(index, 1);

        this.setState({ vpcGroups });

        this.setState({
            vpcRows: FormRows.removeRow(index, this.state.vpcRows),
        });
    };

    handleRequestCloudWatchRowAdd = () => {
         /*
            Adds an empty row to the cwlRows object
         */
        this.setState({
            cloudwatchRows: FormRows.addRow(
                <FormRows.Row
                    index={this.state.cloudwatchRows.length}
                    key={createDOMID()}
                    onRequestRemove={this.handleRequestCloudWatchRowRemove}
                >
                    <Text placeholder="CloudWatch log group name (including prefix)" name={this.state.cwlGroups.length} onChange={this.handleCWLChange} />
                </FormRows.Row>,
                this.state.cloudwatchRows
            ),
        });
    };

    handleRequestCloudWatchRowMove = ({ fromIndex, toIndex }) => {
        /*
            Moves a row in the cwlRows object.
            Also handles the movement of the row user input in the cwlGroups object.
         */
        let cwlGroups = this.state.cwlGroups;
        let tmp = cwlGroups[toIndex];
        cwlGroups[toIndex] = cwlGroups[fromIndex];
        cwlGroups[fromIndex] = tmp;

        this.setState({ cwlGroups });

        this.setState({
            cloudwatchRows: FormRows.moveRow(fromIndex, toIndex, this.state.cloudwatchRows),
        });
    };

    handleRequestCloudWatchRowRemove = (e, { index }) => {
        /*
            Deletes a row in the cwlRows object.
            Also handles the deletion of the row user input in the cwlGroups object.
         */
        let cwlGroups = this.state.cwlGroups;
        cwlGroups.splice(index, 1);

        this.setState({ cwlGroups });

        this.setState({
            cloudwatchRows: FormRows.removeRow(index, this.state.cloudwatchRows),
        });
    };

    handleCWEChange = (e, { values }) => {
        /*
            Update the values state object with the provided list of CloudWatch Events
         */
        this.setState({ values });
    };

    handleCWLChange = (e, { value, name }) => {
        /*
            Adds the user input to the cwlGroups object.
            name contains the current index - use to determine if we need to append or update an existing value
         */
        let cwlGroups = this.state.cwlGroups;
        if (cwlGroups.length <= name) {
            cwlGroups.push(value);
        } else {
            cwlGroups[name] = value;
        }
        this.setState({ cwlGroups })
    }
    ;

    handleVPCChange = (e, { value, name }) => {
        /*
            Adds the user input to the vpcGroups object.
            name contains the current index - use to determine if we need to append or update an existing value
         */
        let vpcGroups = this.state.vpcGroups;
        if (vpcGroups.length <= name) {
            vpcGroups.push(value);
        } else {
            vpcGroups[name] = value;
        }
        this.setState({ vpcGroups })
    };

    handleEndpointChange = (e, { value }) => {
        /*
            Set the EndpointValue state value with the user provided Splunk endpoint
         */
        this.state.EndpointValue = value;
    };

    handleMgmtEndpointChange = (e, { value }) => {
        /*
            Set the SplunkManagementEndpoint state value with the user provided Splunk management endpoint
         */
        this.state.SplunkManagementEndpoint = value;
    };

    handleTokenChange = (e, { value }) => {
        /*
            Set the TokenValue state value with the user provided Splunk HEC Token
         */
        this.state.TokenValue = value;
    };

    handleNoAckTokenChange = (e, { value }) => {
        /*
            Set the TokenValue state value with the user provided Splunk HEC Token
         */
        this.state.NoAckTokenValue = value;
    };

    handleAutoHecClick = () => {
        /*
            When a user selects or deselects automatic HEC token creation - Hide or show the token form inputs,
            also hide or show the Splunk credentials (username/password) form inputs.
         */
        let TokenDisplay = this.state.TokenDisplay;
        let NoAckTokenDisplay = this.state.NoAckTokenDisplay;
        let SplunkCredentialsDisplay = this.state.SplunkCredentialsDisplay;
        let autoHEC = !this.state.autoHEC;

        if (TokenDisplay === 'none') {
            TokenDisplay = "";
        } else {
            TokenDisplay = "none";
        }

        if (NoAckTokenDisplay === 'none') {
            NoAckTokenDisplay = "";
        } else {
            NoAckTokenDisplay = "none";
        }

        if (SplunkCredentialsDisplay === 'none') {
            SplunkCredentialsDisplay = "";
        } else {
            SplunkCredentialsDisplay = "none";
        }

        this.setState({ NoAckTokenDisplay });
        this.setState({ TokenDisplay });
        this.setState({ SplunkCredentialsDisplay });
        this.setState({ autoHEC });
    };

    handleToggleClick(index) {
        /*
            When a toggle is selected - flip the boolean "done" value and set the display to 'none' (not visible)
            or an empty string (visible)
         */
        const items = this.state.items;
        items[index].done = !items[index].done;

        if (items[index].display === 'none') {
            items[index].display = "";
        } else {
            items[index].display = "none";
        }

        this.setState({ items });
    }

    handleDownloadClick() {
         /*
            Called on template download click. Creates an inline JSON object based off of an inline CloudFormation template
            and the selections made by the used in the form. After creating the object, the JSON object is converted to a
            file and downloaded.
        */
        let macro_template = JSON.parse(
            '{"AWSTemplateFormatVersion":"2010-09-09","Description":"Macro template for Cloudwatch log group subscription generation","Mappings":{"BucketMap":{"us-east-1":{"BucketName":"trumpet-splunk-prod-us-east-1"},"us-east-2":{"BucketName":"trumpet-splunk-prod-us-east-2"},"us-west-1":{"BucketName":"trumpet-splunk-prod-us-west-1"},"us-west-2":{"BucketName":"trumpet-splunk-prod-us-west-2"},"ca-central-1":{"BucketName":"trumpet-splunk-prod-ca-central-1"},"eu-central-1":{"BucketName":"trumpet-splunk-prod-eu-central-1"},"eu-west-1":{"BucketName":"trumpet-splunk-prod-eu-west-1"},"eu-west-2":{"BucketName":"trumpet-splunk-prod-eu-west-2"},"eu-west-3":{"BucketName":"trumpet-splunk-prod-eu-west-3"},"ap-northeast-1":{"BucketName":"trumpet-splunk-prod-ap-northeast-1"},"ap-northeast-2":{"BucketName":"trumpet-splunk-prod-ap-northeast-2"},"ap-southeast-1":{"BucketName":"trumpet-splunk-prod-ap-southeast-1"},"ap-southeast-2":{"BucketName":"trumpet-splunk-prod-ap-southeast-2"},"ap-south-1":{"BucketName":"trumpet-splunk-prod-ap-south-1"},"sa-east-1":{"BucketName":"trumpet-splunk-prod-sa-east-1"}}},"Resources":{"CloudwatchLogGroupsSubscriptionGenerator":{"Type":"AWS::CloudFormation::Macro","Properties":{"Description":"Macro","FunctionName":{"Fn::GetAtt":["CloudwatchLogGroupsSubscriptionGeneratorLambda","Arn"]},"Name":"CloudwatchLogGroupsSubscriptionGenerator"}},"CloudwatchLogGroupsSubscriptionGeneratorLambda":{"Type":"AWS::Lambda::Function","Properties":{"Code":{"S3Bucket":{"Fn::FindInMap":["BucketMap",{"Ref":"AWS::Region"},"BucketName"]},"S3Key":"cloudwatch_log_groups_subscription_generator_v0.3.zip"},"Description":"Macro","MemorySize":512,"Handler":"lambda_function.lambda_handler","Role":{"Fn::GetAtt":["CloudwatchLogGroupsSubscriptionGeneratorRole","Arn"]},"Timeout":300,"Runtime":"python3.7","Environment":{"Variables":{"log_group_prefix":"/aws/lambda/"}}}},"CloudwatchLogGroupsSubscriptionGeneratorRole":{"Type":"AWS::IAM::Role","Properties":{"Path":"/","ManagedPolicyArns":["arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"],"Policies":[{"PolicyName":"CloudwatchLogGroupsSubscriptionGeneratorPolicy","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["lambda:InvokeFunction"],"Resource":["*"]},{"Effect":"Allow","Action":["logs:DescribeLogGroups","logs:CreateLogGroup","logs:CreateLogStream","logs:PutLogEvents","logs:DescribeSubscriptionFilters"],"Resource":"*"}]}}],"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":["sts:AssumeRole"],"Effect":"Allow","Principal":{"Service":["lambda.amazonaws.com"]}}]}}}}}'
        );

        // The full JSON parsed generic CloudFormation template
        let template = JSON.parse(
            '{"AWSTemplateFormatVersion":"2010-09-09","Description":"Template for AWS data ingest into Splunk using AWS Kinesis Firehose and AWS Lambda.","Mappings":{"BucketMap":{"us-east-1":{"BucketName":"trumpet-splunk-prod-us-east-1"},"us-east-2":{"BucketName":"trumpet-splunk-prod-us-east-2"},"us-west-1":{"BucketName":"trumpet-splunk-prod-us-west-1"},"us-west-2":{"BucketName":"trumpet-splunk-prod-us-west-2"},"ca-central-1":{"BucketName":"trumpet-splunk-prod-ca-central-1"},"eu-central-1":{"BucketName":"trumpet-splunk-prod-eu-central-1"},"eu-west-1":{"BucketName":"trumpet-splunk-prod-eu-west-1"},"eu-west-2":{"BucketName":"trumpet-splunk-prod-eu-west-2"},"eu-west-3":{"BucketName":"trumpet-splunk-prod-eu-west-3"},"ap-northeast-1":{"BucketName":"trumpet-splunk-prod-ap-northeast-1"},"ap-northeast-2":{"BucketName":"trumpet-splunk-prod-ap-northeast-2"},"ap-southeast-1":{"BucketName":"trumpet-splunk-prod-ap-southeast-1"},"ap-southeast-2":{"BucketName":"trumpet-splunk-prod-ap-southeast-2"},"ap-south-1":{"BucketName":"trumpet-splunk-prod-ap-south-1"},"sa-east-1":{"BucketName":"trumpet-splunk-prod-sa-east-1"}}},"Parameters":{"SplunkUsername":{"Description":"The Splunk user that will be used by the template to configure HEC for Trumpet. This user should have permission to list and create HEC tokens.","Type":"String"},"SplunkPassword":{"Description":"The Splunk password for the provided user.","Type":"String","NoEcho":true}},"Metadata":{"AWS::CloudFormation::Interface":{"ParameterGroups":[{"Label":{"default":"Splunk credentials"},"Parameters":["SplunkUsername","SplunkPassword"]}],"ParameterLabels":{"SplunkUsername":{"default":"Splunk username"},"SplunkPassword":{"default":"Splunk password"}}}},"Resources":{"LambdaHecAutomation":{"Type":"AWS::Lambda::Function","Properties":{"Code":{"S3Bucket":{"Fn::FindInMap":["BucketMap",{"Ref":"AWS::Region"},"BucketName"]},"S3Key":"hec_auto_v0.3.zip"},"Handler":"index.handler","Role":{"Fn::GetAtt":["LambdaHecAutomationExecutionRole","Arn"]},"Runtime":"python3.7","Timeout":"30"}},"LambdaHecAutomationExecutionRole":{"Type":"AWS::IAM::Role","Properties":{"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":["lambda.amazonaws.com"]},"Action":["sts:AssumeRole"]}]},"Path":"/","Policies":[{"PolicyName":"root","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["logs:CreateLogGroup","logs:CreateLogStream","logs:PutLogEvents"],"Resource":"arn:aws:logs:*:*:*"}]}}]}},"CustomResourceHecAutomation":{"Type":"Custom::CustomResource","Properties":{"ServiceToken":{"Fn::GetAtt":["LambdaHecAutomation","Arn"]},"SplunkUser":"","SplunkPassword":"","SplunkHttpEventCollectorManagementURL":"","AWSRegion":{"Ref":"AWS::Region"}}},"ConfigurationRecorderSanitizationLambdaExecutionRole":{"Type":"AWS::IAM::Role","Properties":{"Path":"/","Policies":[{"PolicyName":"ConfigurationRecorderSanitizationLambdaExecutionRole","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":["iam:PassRole"],"Resource":[{"Fn::GetAtt":["BackingLambdaExecutionConfigLogProcessor","Arn"]}],"Effect":"Allow"},{"Action":["logs:CreateLogGroup","logs:CreateLogStream","logs:PutLogEvents"],"Resource":"arn:aws:logs:*:*:*","Effect":"Allow"},{"Action":["config:DescribeConfigurationRecorders","config:DescribeDeliveryChannels","config:PutConfigurationRecorder","config:StartConfigurationRecorder","config:PutDeliveryChannel","config:DescribeConfigurationRecorderStatus"],"Resource":["*"],"Effect":"Allow"},{"Action":["iam:PassRole"],"Resource":[{"Fn::GetAtt":["ConfigRole","Arn"]}],"Effect":"Allow"}]}}],"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":["sts:AssumeRole"],"Effect":"Allow","Principal":{"Service":["lambda.amazonaws.com"]}}]}}},"ConfigBucketPermission":{"Type":"AWS::Lambda::Permission","Properties":{"Action":"lambda:InvokeFunction","SourceAccount":{"Ref":"AWS::AccountId"},"Principal":"s3.amazonaws.com","FunctionName":{"Ref":"BackingLambdaConfigLogProcessor"},"SourceArn":{"Fn::GetAtt":["ConfigurationRecorderSanitisationResults","FinalS3BucketConfigArn"]}}},"BackingLambdaConfigLogProcessor":{"Type":"AWS::Lambda::Function","Properties":{"Code":{"S3Bucket":{"Fn::FindInMap":["BucketMap",{"Ref":"AWS::Region"},"BucketName"]},"S3Key":"config_snapshot_logger_v0.3.zip"},"Description":"Stream events from an AWS S3 bucket being updated by AWS config to Splunk using HTTP event collector","MemorySize":512,"Environment":{"Variables":{"SPLUNK_HEC_URL":"","SPLUNK_HEC_TOKEN":""}},"Handler":"index.handler","Role":{"Fn::GetAtt":["BackingLambdaExecutionConfigLogProcessorRole","Arn"]},"Timeout":900,"Runtime":"nodejs12.x"}},"ConfigurationRecorderLambdaExecutionRole":{"Type":"AWS::IAM::Role","Properties":{"Path":"/","ManagedPolicyArns":["arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"],"Policies":[{"PolicyName":"ConfigLambdaExecutionRolePolicy","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":["s3:PutObject","s3:DeleteObject","s3:GetBucketPolicy","s3:PutBucketNotification"],"Resource":{"Fn::GetAtt":["ConfigurationRecorderSanitisationResults","FinalS3BucketConfigArn"]},"Effect":"Allow"}]}}],"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":["sts:AssumeRole"],"Effect":"Allow","Principal":{"Service":["lambda.amazonaws.com"]}}]}}},"CloudTrailEventRule":{"Type":"AWS::Events::Rule","Properties":{"EventPattern":{"detail-type":["AWS API Call via CloudTrail","AWS Console Sign In via CloudTrail"]},"State":"ENABLED","Targets":[{"RoleArn":{"Fn::GetAtt":["CWEFirehoseDeliveryRole","Arn"]},"Id":"splunk_cloudtrail_firehose_target","Arn":{"Fn::GetAtt":["CWEFirehoseDeliveryStream","Arn"]}}]}},"ConfigBucketConfiguration":{"Type":"Custom::S3ConfigBucketConfiguration","Properties":{"ServiceToken":{"Fn::GetAtt":["ConfigUpdateBucketConfiguration","Arn"]},"Bucket":{"Fn::GetAtt":["ConfigurationRecorderSanitisationResults","FinalS3BucketConfig"]},"NotificationConfiguration":{"LambdaFunctionConfigurations":[{"LambdaFunctionArn":{"Fn::GetAtt":["BackingLambdaConfigLogProcessor","Arn"]},"Events":["s3:ObjectCreated:*"]}]}},"DependsOn":["ConfigBucketPermission"]},"ConfigurationRecorderSanitiser":{"Type":"AWS::Lambda::Function","Properties":{"Code":{"S3Bucket":{"Fn::FindInMap":["BucketMap",{"Ref":"AWS::Region"},"BucketName"]},"S3Key":"config_discovery_v0.3.zip"},"Runtime":"nodejs12.x","Handler":"index.handler","Role":{"Fn::GetAtt":["ConfigurationRecorderSanitizationLambdaExecutionRole","Arn"]},"Timeout":300}},"BackingLambdaExecutionConfigLogProcessor":{"Type":"AWS::IAM::Role","Properties":{"Path":"/","ManagedPolicyArns":["arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"],"Policies":[{"PolicyName":"BackingLambdaExecutionCloudTrailLogProcessorPolicy","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":["s3:getObject","s3:putObject","s3:ListBucket"],"Resource":{"Fn::Join":["",["arn:aws:s3:::",{"Ref":"S3BucketConfig"},"/*"]]},"Effect":"Allow"}]}}],"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":["sts:AssumeRole"],"Effect":"Allow","Principal":{"Service":["lambda.amazonaws.com"]}}]}}},"ConfigUpdateBucketConfiguration":{"Type":"AWS::Lambda::Function","Properties":{"Code":{"ZipFile":{"Fn::Sub":"var https = require(\'https\');\\nvar url = require(\'url\');\\nvar AWS = require(\'aws-sdk\');\\nfunction send(event, context, status, payload) {\\n    var body = JSON.stringify({\\n        StackId: event.StackId,\\n        RequestId: event.RequestId,\\n        LogicalResourceId: event.LogicalResourceId,\\n        NoEcho: false,\\n        Data: payload,\\n        Status: status,\\n        Reason: \'See the details in CloudWatch Log Stream: \' + context.logStreamName,\\n        PhysicalResourceId: context.logStreamName\\n    });\\n    var requestOptions = {\\n        headers: {\\n            \'content-length\': body.length,\\n            \'content-type\': \'\'\\n        },\\n        hostname: url.parse(event.ResponseURL).hostname,\\n        port: 443,\\n        path: url.parse(event.ResponseURL).path,\\n        method: \'PUT\'\\n    };\\n    var makeRequest = https.request(requestOptions, function(response) {\\n        context.done();\\n    });\\n    makeRequest.on(\'error\', function(error) {\\n        context.done();\\n    });\\n    makeRequest.write(body);\\n    makeRequest.end();\\n}\\nvar s3 = new AWS.S3();\\nexports.handler = function(event, context) {\\n  var respond = (e) => send(event, context, e ? \'FAILED\' : \'SUCCESS\', e ? e : {});\\n  var params = event.ResourceProperties;\\n  delete params.ServiceToken;\\n  if (event.RequestType === \'Delete\') {\\n    params.NotificationConfiguration = {};\\n    s3.putBucketNotificationConfiguration(params).promise()\\n      .then((data)=>respond())\\n      .catch((e)=>respond());\\n  } else {\\n    s3.putBucketNotificationConfiguration(params).promise()\\n      .then((data)=>respond())\\n      .catch((e)=>respond(e));\\n  }\\n};\\n"}},"Role":{"Fn::GetAtt":["ConfigurationRecorderLambdaExecutionRole","Arn"]},"Description":"S3 Object Custom Resource","Timeout":300,"Handler":"index.handler","Runtime":"nodejs12.x"}},"S3BucketConfig":{"Type":"AWS::S3::Bucket","Properties":{"VersioningConfiguration":{"Status":"Enabled"}}},"ConfigurationRecorderSanitisationResults":{"Type":"Custom::ConfigurationRecorderSanitisationResults","Properties":{"S3BucketConfig":{"Ref":"S3BucketConfig"},"RoleARN":{"Fn::GetAtt":["BackingLambdaExecutionConfigLogProcessor","Arn"]},"ConfigRecorderName":"ConfigRecorder","ServiceToken":{"Fn::GetAtt":["ConfigurationRecorderSanitiser","Arn"]},"S3BucketConfigArn":{"Fn::GetAtt":["S3BucketConfig","Arn"]},"RecorderRoleArn":{"Fn::GetAtt":["ConfigRole","Arn"]}}},"ConfigNotificationEventRule":{"Type":"AWS::Events::Rule","Properties":{"EventPattern":{"source":["aws.config"],"detail-type":["Config Configuration Item Change"]},"State":"ENABLED","Targets":[{"RoleArn":{"Fn::GetAtt":["CWEFirehoseDeliveryRole","Arn"]},"Id":"splunk_config_notification_firehose_target","Arn":{"Fn::GetAtt":["CWEFirehoseDeliveryStream","Arn"]}}]}},"CWEFirehoseProcessor":{"Type":"AWS::Lambda::Function","Properties":{"Code":{"S3Bucket":{"Fn::FindInMap":["BucketMap",{"Ref":"AWS::Region"},"BucketName"]},"S3Key":"splunk_cwe_firehose_processor_v0.3.zip"},"Description":"Stream events from CloudWatch Events to Splunk using HTTP event collector","MemorySize":512,"Handler":"lambda_function.handler","Role":{"Fn::GetAtt":["CWEFirehoseProcessorRole","Arn"]},"Timeout":300,"Runtime":"python3.7"}},"CWEFindingEventRule":{"Type":"AWS::Events::Rule","Properties":{"EventPattern":{"source":[],"detail-type":[]},"State":"ENABLED","Targets":[{"RoleArn":{"Fn::GetAtt":["CWEFirehoseDeliveryRole","Arn"]},"Id":"splunk_cwe_firehose_target","Arn":{"Fn::GetAtt":["CWEFirehoseDeliveryStream","Arn"]}}]}},"CWEFirehoseDeliveryStream":{"Type":"AWS::KinesisFirehose::DeliveryStream","Properties":{"SplunkDestinationConfiguration":{"S3Configuration":{"CompressionFormat":"UNCOMPRESSED","BucketARN":{"Fn::GetAtt":["CWEBackupS3Bucket","Arn"]},"RoleARN":{"Fn::GetAtt":["CWEBackupS3Role","Arn"]},"BufferingHints":{"IntervalInSeconds":300,"SizeInMBs":1}},"HECEndpointType":"Event","HECToken":"SPLUNK_HEC_TOKEN","HECAcknowledgmentTimeoutInSeconds":180,"RetryOptions":{"DurationInSeconds":300},"HECEndpoint":"SPLUNK_HEC_URL","S3BackupMode":"FailedEventsOnly","ProcessingConfiguration":{"Enabled":true,"Processors":[{"Parameters":[{"ParameterName":"LambdaArn","ParameterValue":{"Fn::GetAtt":["CWEFirehoseProcessor","Arn"]}},{"ParameterName":"RoleArn","ParameterValue":{"Fn::GetAtt":["CWEBackupS3Role","Arn"]}}],"Type":"Lambda"}]}},"DeliveryStreamType":"DirectPut"}},"CWEFirehoseDeliveryRole":{"Type":"AWS::IAM::Role","Properties":{"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":"sts:AssumeRole","Sid":"","Effect":"Allow","Principal":{"Service":"events.amazonaws.com"}}]}}},"CWEFirehoseDeliveryPolicy":{"Type":"AWS::IAM::Policy","Properties":{"PolicyName":"firehose_delivery_policy","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":["firehose:PutRecord","firehose:PutRecordBatch"],"Resource":[{"Fn::GetAtt":["CWEFirehoseDeliveryStream","Arn"]}],"Effect":"Allow"}]},"Roles":[{"Ref":"CWEFirehoseDeliveryRole"}]}},"CWEBackupS3Bucket":{"Type":"AWS::S3::Bucket","Properties":{"VersioningConfiguration":{"Status":"Enabled"}}},"CWEBackupS3Role":{"Type":"AWS::IAM::Role","Properties":{"Path":"/","Policies":[{"PolicyName":"CWEBackupS3Role","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Sid":"","Effect":"Allow","Action":["glue:GetTableVersions"],"Resource":"*"},{"Sid":"","Effect":"Allow","Action":["s3:AbortMultipartUpload","s3:GetBucketLocation","s3:GetObject","s3:ListBucket","s3:ListBucketMultipartUploads","s3:PutObject"],"Resource":"*"},{"Sid":"","Effect":"Allow","Action":["lambda:InvokeFunction","lambda:GetFunctionConfiguration"],"Resource":"*"},{"Sid":"","Effect":"Allow","Action":["logs:CreateLogGroup","logs:CreateLogStream","logs:PutLogEvents"],"Resource":"*"},{"Sid":"","Effect":"Allow","Action":["kinesis:DescribeStream","kinesis:GetShardIterator","kinesis:GetRecords"],"Resource":"*"},{"Sid":"","Effect":"Allow","Action":["kms:Decrypt"],"Resource":"*","Condition":{"StringEquals":{"kms:ViaService":{"Fn::Join":["",["kinesis.",{"Ref":"AWS::Region"},".amazonaws.com"]]}},"StringLike":{"kms:EncryptionContext:aws:kinesis:arn":{"Fn::Join":["",["arn:aws:kinesis:",{"Ref":"AWS::Region"},":",{"Ref":"AWS::AccountId"},":stream/%FIREHOSE_STREAM_NAME%"]]}}}}]}}],"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":"sts:AssumeRole","Sid":"","Effect":"Allow","Principal":{"Service":"firehose.amazonaws.com"}}]}}},"CWEFirehoseProcessorRole":{"Type":"AWS::IAM::Role","Properties":{"Path":"/","ManagedPolicyArns":["arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"],"Policies":[{"PolicyName":"CWEFirehoseProcessorPolicy","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["lambda:InvokeFunction"],"Resource":["*"]},{"Effect":"Allow","Action":["kinesis:GetRecords","kinesis:GetShardIterator","kinesis:DescribeStream","kinesis:ListStreams","logs:CreateLogGroup","logs:CreateLogStream","logs:PutLogEvents"],"Resource":"*"}]}}],"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":["sts:AssumeRole"],"Effect":"Allow","Principal":{"Service":["lambda.amazonaws.com"]}}]}}},"CWLFirehoseProcessor":{"Type":"AWS::Lambda::Function","Properties":{"Code":{"S3Bucket":{"Fn::FindInMap":["BucketMap",{"Ref":"AWS::Region"},"BucketName"]},"S3Key":"splunk_cwl_firehose_processor_v0.3.zip"},"Description":"Stream events from CloudWatch Logs to Splunk using HTTP event collector","MemorySize":512,"Handler":"lambda_function.handler","Role":{"Fn::GetAtt":["CWLFirehoseProcessorRole","Arn"]},"Timeout":300,"Runtime":"python3.7"}},"CWLtoKinesisFirehoseRole":{"Type":"AWS::IAM::Role","Properties":{"Policies":[{"PolicyName":"CWLtoKinesisFirehosePolicy","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["firehose:*"],"Resource":["arn:aws:firehose:*:*:*"]},{"Effect":"Allow","Action":["iam:PassRole"],"Resource":["arn:aws:iam::*:role/CWLtoKinesisFirehoseRole"]}]}}],"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":{"Action":"sts:AssumeRole","Effect":"Allow","Principal":{"Service":{"Fn::Join":["",["logs.",{"Ref":"AWS::Region"},".amazonaws.com"]]}}}}}},"CWLFlowLogSubscriptionFilter":{"Type":"AWS::Logs::SubscriptionFilter","Properties":{"RoleArn":{"Fn::GetAtt":["CWLtoKinesisFirehoseRole","Arn"]},"LogGroupName":"placeholder","FilterPattern":"","DestinationArn":{"Fn::GetAtt":["CWLFirehoseDeliveryStream","Arn"]}}},"CWLFirehoseDeliveryStream":{"Type":"AWS::KinesisFirehose::DeliveryStream","Properties":{"SplunkDestinationConfiguration":{"S3Configuration":{"CompressionFormat":"UNCOMPRESSED","BucketARN":{"Fn::GetAtt":["CWLBackupS3Bucket","Arn"]},"RoleARN":{"Fn::GetAtt":["CWLBackupS3Role","Arn"]},"BufferingHints":{"IntervalInSeconds":300,"SizeInMBs":1}},"HECEndpointType":"Event","HECToken":"SPLUNK_HEC_TOKEN","HECAcknowledgmentTimeoutInSeconds":180,"RetryOptions":{"DurationInSeconds":300},"HECEndpoint":"SPLUNK_HEC_URL","S3BackupMode":"FailedEventsOnly","ProcessingConfiguration":{"Enabled":true,"Processors":[{"Parameters":[{"ParameterName":"LambdaArn","ParameterValue":{"Fn::GetAtt":["CWLFirehoseProcessor","Arn"]}},{"ParameterName":"RoleArn","ParameterValue":{"Fn::GetAtt":["CWLBackupS3Role","Arn"]}}],"Type":"Lambda"}]}},"DeliveryStreamType":"DirectPut"}},"CWLFirehoseDeliveryRole":{"Type":"AWS::IAM::Role","Properties":{"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":"sts:AssumeRole","Sid":"","Effect":"Allow","Principal":{"Service":"events.amazonaws.com"}}]}}},"CWLFirehoseDeliveryPolicy":{"Type":"AWS::IAM::Policy","Properties":{"PolicyName":"firehose_delivery_policy","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":["firehose:PutRecord","firehose:PutRecordBatch"],"Resource":[{"Fn::GetAtt":["CWLFirehoseDeliveryStream","Arn"]}],"Effect":"Allow"}]},"Roles":[{"Ref":"CWLFirehoseDeliveryRole"}]}},"CWLBackupS3Bucket":{"Type":"AWS::S3::Bucket","Properties":{"VersioningConfiguration":{"Status":"Enabled"}}},"CWLBackupS3Role":{"Type":"AWS::IAM::Role","Properties":{"Path":"/","Policies":[{"PolicyName":"CWLBackupS3Role","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Sid":"","Effect":"Allow","Action":["glue:GetTableVersions"],"Resource":"*"},{"Sid":"","Effect":"Allow","Action":["s3:AbortMultipartUpload","s3:GetBucketLocation","s3:GetObject","s3:ListBucket","s3:ListBucketMultipartUploads","s3:PutObject"],"Resource":"*"},{"Sid":"","Effect":"Allow","Action":["lambda:InvokeFunction","lambda:GetFunctionConfiguration"],"Resource":"*"},{"Sid":"","Effect":"Allow","Action":["logs:CreateLogGroup","logs:CreateLogStream","logs:PutLogEvents"],"Resource":"*"},{"Sid":"","Effect":"Allow","Action":["kinesis:DescribeStream","kinesis:GetShardIterator","kinesis:GetRecords"],"Resource":"*"},{"Sid":"","Effect":"Allow","Action":["kms:Decrypt"],"Resource":{"Fn::Join":["",["arn:aws:kms:",{"Ref":"AWS::Region"},":",{"Ref":"AWS::AccountId"},":key/%SSE_KEY_ARN%"]]},"Condition":{"StringEquals":{"kms:ViaService":{"Fn::Join":["",["kinesis.",{"Ref":"AWS::Region"},".amazonaws.com"]]}},"StringLike":{"kms:EncryptionContext:aws:kinesis:arn":{"Fn::Join":["",["arn:aws:kinesis:",{"Ref":"AWS::Region"},":",{"Ref":"AWS::AccountId"},":stream/%FIREHOSE_STREAM_NAME%"]]}}}}]}}],"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":"sts:AssumeRole","Sid":"","Effect":"Allow","Principal":{"Service":"firehose.amazonaws.com"}}]}}},"CWLFirehoseProcessorRole":{"Type":"AWS::IAM::Role","Properties":{"Path":"/","ManagedPolicyArns":["arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"],"Policies":[{"PolicyName":"CWLFirehoseProcessorPolicy","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":"logs:CreateLogGroup","Resource":"arn:aws:logs:*:*:*"},{"Effect":"Allow","Action":["logs:CreateLogStream","logs:PutLogEvents"],"Resource":["arn:aws:logs:*:*:*:*:*"]}]}}],"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":["sts:AssumeRole"],"Effect":"Allow","Principal":{"Service":["lambda.amazonaws.com"]}}]}}},"VPCtoKinesisFirehoseRole":{"Type":"AWS::IAM::Role","Properties":{"Policies":[{"PolicyName":"VPCtoKinesisFirehosePolicy","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["firehose:*"],"Resource":["arn:aws:firehose:*:*:*"]},{"Effect":"Allow","Action":["iam:PassRole"],"Resource":["arn:aws:iam::*:role/VPCtoKinesisFirehoseRole"]}]}}],"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":{"Action":"sts:AssumeRole","Effect":"Allow","Principal":{"Service":{"Fn::Join":["",["logs.",{"Ref":"AWS::Region"},".amazonaws.com"]]}}}}}},"VPCFlowLogSubscriptionFilter":{"Type":"AWS::Logs::SubscriptionFilter","Properties":{"RoleArn":{"Fn::GetAtt":["VPCtoKinesisFirehoseRole","Arn"]},"LogGroupName":"placeholder","FilterPattern":"","DestinationArn":{"Fn::GetAtt":["VPCFirehoseDeliveryStream","Arn"]}}},"VPCFirehoseDeliveryStream":{"Type":"AWS::KinesisFirehose::DeliveryStream","Properties":{"SplunkDestinationConfiguration":{"S3Configuration":{"CompressionFormat":"UNCOMPRESSED","BucketARN":{"Fn::GetAtt":["VPCBackupS3Bucket","Arn"]},"RoleARN":{"Fn::GetAtt":["VPCBackupS3Role","Arn"]},"BufferingHints":{"IntervalInSeconds":300,"SizeInMBs":1}},"HECEndpointType":"Event","HECToken":"SPLUNK_HEC_TOKEN","HECAcknowledgmentTimeoutInSeconds":180,"RetryOptions":{"DurationInSeconds":300},"HECEndpoint":"SPLUNK_HEC_URL","S3BackupMode":"FailedEventsOnly","ProcessingConfiguration":{"Enabled":true,"Processors":[{"Parameters":[{"ParameterName":"LambdaArn","ParameterValue":{"Fn::GetAtt":["VPCFirehoseProcessor","Arn"]}},{"ParameterName":"RoleArn","ParameterValue":{"Fn::GetAtt":["VPCBackupS3Role","Arn"]}}],"Type":"Lambda"}]}},"DeliveryStreamType":"DirectPut"}},"VPCFirehoseDeliveryRole":{"Type":"AWS::IAM::Role","Properties":{"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":"sts:AssumeRole","Sid":"","Effect":"Allow","Principal":{"Service":"events.amazonaws.com"}}]}}},"VPCFirehoseDeliveryPolicy":{"Type":"AWS::IAM::Policy","Properties":{"PolicyName":"firehose_delivery_policy","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":["firehose:PutRecord","firehose:PutRecordBatch"],"Resource":[{"Fn::GetAtt":["VPCFirehoseDeliveryStream","Arn"]}],"Effect":"Allow"}]},"Roles":[{"Ref":"VPCFirehoseDeliveryRole"}]}},"VPCBackupS3Bucket":{"Type":"AWS::S3::Bucket","Properties":{"VersioningConfiguration":{"Status":"Enabled"}}},"VPCBackupS3Role":{"Type":"AWS::IAM::Role","Properties":{"Path":"/","Policies":[{"PolicyName":"VPCBackupS3Role","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":["s3:AbortMultipartUpload","s3:GetBucketLocation","s3:GetObject","s3:ListBucket","s3:ListBucketMultipartUploads","s3:PutObject"],"Resource":"*","Effect":"Allow"},{"Effect":"Allow","Action":["lambda:InvokeFunction","lambda:GetFunctionConfiguration"],"Resource":"*"},{"Action":["logs:CreateLogGroup","logs:CreateLogStream","logs:PutLogEvents"],"Resource":"*","Effect":"Allow"}]}}],"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":"sts:AssumeRole","Sid":"","Effect":"Allow","Principal":{"Service":"firehose.amazonaws.com"}}]}}},"VPCFirehoseProcessorRole":{"Type":"AWS::IAM::Role","Properties":{"Path":"/","ManagedPolicyArns":["arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"],"Policies":[{"PolicyName":"VPCFirehoseProcessorPolicy","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":"logs:CreateLogGroup","Resource":"arn:aws:logs:*:*:*"},{"Effect":"Allow","Action":["logs:CreateLogStream","logs:PutLogEvents"],"Resource":["arn:aws:logs:*:*:*:*:*"]}]}}],"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":["sts:AssumeRole"],"Effect":"Allow","Principal":{"Service":["lambda.amazonaws.com"]}}]}}},"VPCFirehoseProcessor":{"Type":"AWS::Lambda::Function","Properties":{"Code":{"S3Bucket":{"Fn::FindInMap":["BucketMap",{"Ref":"AWS::Region"},"BucketName"]},"S3Key":"splunk_vpc_firehose_processor_v0.3.zip"},"Description":"Stream events from VPC Flow Logs to Splunk using HTTP event collector","MemorySize":512,"Handler":"lambda_function.handler","Role":{"Fn::GetAtt":["VPCFirehoseProcessorRole","Arn"]},"Timeout":300,"Runtime":"python3.7"}},"ConfigRole":{"Type":"AWS::IAM::Role","Properties":{"ManagedPolicyArns":["arn:aws:iam::aws:policy/service-role/AWSConfigRole"],"Policies":[{"PolicyName":"ConfigRolePolicy","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":["s3:PutObject"],"Resource":{"Fn::Join":["",["arn:aws:s3:::",{"Ref":"S3BucketConfig"},"/AWSLogs/",{"Ref":"AWS::AccountId"},"/*"]]},"Effect":"Allow","Condition":{"StringLike":{"s3:x-amz-acl":"bucket-owner-full-control"}}},{"Action":"config:Put*","Resource":"*","Effect":"Allow"},{"Action":["s3:GetBucketAcl"],"Resource":{"Fn::Join":["",["arn:aws:s3:::",{"Ref":"S3BucketConfig"}]]},"Effect":"Allow"}]}}],"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":"sts:AssumeRole","Sid":"","Effect":"Allow","Principal":{"Service":"config.amazonaws.com"}}]}}},"BackingLambdaExecutionConfigLogProcessorRole":{"Type":"AWS::IAM::Role","Properties":{"Path":"/","ManagedPolicyArns":["arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"],"Policies":[{"PolicyName":"BackingLambdaExecutionConfigLogProcessorPolicy","PolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":["s3:getObject","s3:putObject","s3:ListBucket"],"Resource":{"Fn::Join":["",[{"Fn::GetAtt":["ConfigurationRecorderSanitisationResults","FinalS3BucketConfigArn"]},"/AWSLogs/",{"Ref":"AWS::AccountId"},"/*"]]},"Effect":"Allow"}]}}],"AssumeRolePolicyDocument":{"Version":"2012-10-17","Statement":[{"Action":["sts:AssumeRole"],"Effect":"Allow","Principal":{"Service":["lambda.amazonaws.com"]}}]}}}}}'
        );

        // Grab all needed state variables for easier visibility
        let AUTO_HEC = this.state.autoHEC;
        let HEC_ENDPOINT = this.state.EndpointValue;
        let HEC_TOKEN = this.state.TokenValue;
        let NO_ACK_HEC_TOKEN = this.state.NoAckTokenValue;
        let SPLUNK_MGMT_ENDPOINT = this.state.SplunkManagementEndpoint;
        let cwe_event_type_selections = this.state.values;
        let cwe_event_service_map = this.state.cwe_event_service_map;
        let cwlGroups = this.state.cwlGroups;
        let vpcGroups = this.state.vpcGroups;
        let log_group_prefix = this.state.log_group_prefix;
        let macro = false;

        const items = this.state.items;

        // CloudFormation template parameter entries for automatic HEC token creation
        let AUTO_HEC_NO_ACK_TOKEN = {
                "Fn::GetAtt": [
                  "CustomResourceHecAutomation",
                  "IndexerNoAckHECToken"
                ]
              };

        let AUTO_HEC_ACK_TOKEN = {
                "Fn::GetAtt": [
                  "CustomResourceHecAutomation",
                  "IndexerAckHECToken"
                ]
              };

        /*
            Index mapping for the items object:

            0: AWS Config Notifications
            1: AWS Config Snapshots
            2: AWS CloudTrail
            3: VPC Flow logs
            4: CloudWatch logs
            5: CloudWatch Events
        */

        if (!AUTO_HEC) {
            // Delete all artifacts related to auto HEC creation lambda shim
            delete template["Resources"]["LambdaHecAutomation"];
            delete template["Resources"]["LambdaHecAutomationExecutionRole"];
            delete template["Resources"]["CustomResourceHecAutomation"];

            delete template["Parameters"];
            delete template["Metadata"];
        } else {
            // Configure the Lambda shim with Splunk credentials
            template["Resources"]["CustomResourceHecAutomation"]["Properties"]["SplunkUser"] = { "Ref": "SplunkUsername" };
            template["Resources"]["CustomResourceHecAutomation"]["Properties"]["SplunkPassword"] = { "Ref": "SplunkPassword" };
            template["Resources"]["CustomResourceHecAutomation"]["Properties"]["SplunkHttpEventCollectorManagementURL"] = SPLUNK_MGMT_ENDPOINT
        }

        if (macro) {
            macro_template["Resources"]["CloudwatchLogGroupsSubscriptionGeneratorLambda"]["Properties"]["Environment"]["Variables"]["log_group_prefix"] = log_group_prefix
        }

        // Config Notification
        if (!items[0].done) {
            // Config Notification collection not selected. Delete all resources related to Config Notification logging from template
            delete template["Resources"]["ConfigNotificationEventRule"];
        } else {
            // Add Splunk details
            template["Resources"]["CWEFirehoseDeliveryStream"]["Properties"]["SplunkDestinationConfiguration"]["HECEndpoint"] = HEC_ENDPOINT;
            if (!AUTO_HEC) {
                template["Resources"]["CWEFirehoseDeliveryStream"]["Properties"]["SplunkDestinationConfiguration"]["HECToken"] = HEC_TOKEN;
            } else {
                template["Resources"]["CWEFirehoseDeliveryStream"]["Properties"]["SplunkDestinationConfiguration"]["HECToken"] = AUTO_HEC_ACK_TOKEN;
            }

        }

        // Config Snapshot
        if (!items[1].done) {
            // Config Snapshot collection not selected. Delete all resources related to Config Snapshot logging from template
            delete template["Resources"]["S3BucketConfig"];
            delete template["Resources"]["ConfigRole"];
            delete template["Resources"]["BackingLambdaExecutionConfigLogProcessorRole"];
            delete template["Resources"]["BackingLambdaConfigLogProcessor"];
            delete template["Resources"]["ConfigBucketConfiguration"];
            delete template["Resources"]["ConfigUpdateBucketConfiguration"];
            delete template["Resources"]["ConfigBucketPermission"];
            delete template["Resources"]["ConfigurationRecorderLambdaExecutionRole"];
            delete template["Resources"]["ConfigurationRecorderSanitiser"];
            delete template["Resources"]["BackingLambdaExecutionConfigLogProcessor"];
            delete template["Resources"]["ConfigurationRecorderSanitizationLambdaExecutionRole"];
            delete template["Resources"]["ConfigurationRecorderSanitisationResults"];
        } else {
            // Add Splunk details
            template["Resources"]["BackingLambdaConfigLogProcessor"]["Properties"]["Environment"]["Variables"]["SPLUNK_HEC_URL"] = HEC_ENDPOINT;
            if (!AUTO_HEC) {
                template["Resources"]["BackingLambdaConfigLogProcessor"]["Properties"]["Environment"]["Variables"]["SPLUNK_HEC_TOKEN"] = NO_ACK_HEC_TOKEN;
            } else {
                template["Resources"]["BackingLambdaConfigLogProcessor"]["Properties"]["Environment"]["Variables"]["SPLUNK_HEC_TOKEN"] = AUTO_HEC_NO_ACK_TOKEN;
            }

        }

        // CloudTrail
        if (!items[2].done) {
            // CloudTrail collection not selected. Delete all resources related only to CloudTrail logging from template
            delete template["Resources"]["CloudTrailEventRule"];
        } else {
            // Add Splunk details
            template["Resources"]["CWEFirehoseDeliveryStream"]["Properties"]["SplunkDestinationConfiguration"]["HECEndpoint"] = HEC_ENDPOINT;
            if (!AUTO_HEC) {
                template["Resources"]["CWEFirehoseDeliveryStream"]["Properties"]["SplunkDestinationConfiguration"]["HECToken"] = HEC_TOKEN;
            } else {
                template["Resources"]["CWEFirehoseDeliveryStream"]["Properties"]["SplunkDestinationConfiguration"]["HECToken"] = AUTO_HEC_ACK_TOKEN;
            }

        }

        // VPC FLow logs
         /*
            VPC Flow log object template:
                Note: "LogGroupName" will be replaced by user provided Flow log group/s

            Format:
                "VPCFlowLogSubscriptionFilter" : {
                    "Type" : "AWS::Logs::SubscriptionFilter",
                    "Properties" : {
                        "RoleArn" : { "Fn::GetAtt" : [ "PCtoKinesisFirehoseRole", "Arn" ] },
                        "LogGroupName" : "placeholder",
                        "FilterPattern" : "",
                        "DestinationArn" : { "Fn::GetAtt" : [ "VPCFirehoseDeliveryStream", "Arn" ] }
                    }
                }
         */
        if (!items[3].done) {
            // VPC Flow log collection not selected. Delete all resources related only to CloudWatch VPC Flow log collection
            delete template["Resources"]["VPCBackupS3Bucket"];
            delete template["Resources"]["VPCBackupS3Role"];
            delete template["Resources"]["VPCDeliveryRole"];
            delete template["Resources"]["VPCFirehoseProcessor"];
            delete template["Resources"]["VPCFirehoseProcessorRole"];
            delete template["Resources"]["VPCFirehoseDeliveryPolicy"];
            delete template["Resources"]["VPCFirehoseDeliveryRole"];
            delete template["Resources"]["VPCFlowLogSubscriptionFilter"];
            delete template["Resources"]["VPCtoKinesisFirehoseRole"];
            delete template["Resources"]["VPCFirehoseDeliveryStream"];
        } else {
            let subscription_filter_template = template["Resources"]["VPCFlowLogSubscriptionFilter"];

            // We are logging one or more CloudWatch VPC Flow logs. Set up template accordingly for each vpc flow log group provided by the user
            for (let i=0; i<vpcGroups.length; i++) {
                let vpcGroup = vpcGroups[i];
                let vpcGroup_clean = "VPCFlowLogSubscriptionFilter" + (vpcGroup.toLowerCase()).split(' ').join('').replace(/\W/g, '');
                template["Resources"][vpcGroup_clean] = JSON.parse(JSON.stringify(subscription_filter_template));
                template["Resources"][vpcGroup_clean]["Properties"]["LogGroupName"] = vpcGroup;
            }

            // Delete the empty template section
            delete template["Resources"]["VPCFlowLogSubscriptionFilter"];

             // Add Splunk details
            template["Resources"]["VPCFirehoseDeliveryStream"]["Properties"]["SplunkDestinationConfiguration"]["HECEndpoint"] = HEC_ENDPOINT;
            if (!AUTO_HEC) {
                template["Resources"]["VPCFirehoseDeliveryStream"]["Properties"]["SplunkDestinationConfiguration"]["HECToken"] = HEC_TOKEN;
            } else {
                template["Resources"]["VPCFirehoseDeliveryStream"]["Properties"]["SplunkDestinationConfiguration"]["HECToken"] = AUTO_HEC_ACK_TOKEN;
            }

        }

        // CloudWatch Logs
        /*
            CloudWatch log object template:
                Note: "LogGroupName" will be replaced by user provided log group/s

            Format:
                "CWLFlowLogSubscriptionFilter" : {
                    "Type" : "AWS::Logs::SubscriptionFilter",
                    "Properties" : {
                        "RoleArn" : { "Fn::GetAtt" : [ "CWLtoKinesisFirehoseRole", "Arn" ] },
                        "LogGroupName" : "placeholder",
                        "FilterPattern" : "",
                        "DestinationArn" : { "Fn::GetAtt" : [ "CWLFirehoseDeliveryStream", "Arn" ] }
                    }
                }
         */
        if (!items[4].done) {
            // CloudWatch log collection not selected. Delete all resources related only to CloudWatch log collection
            delete template["Resources"]["CWLBackupS3Bucket"];
            delete template["Resources"]["CWLBackupS3Role"];
            delete template["Resources"]["CWLDeliveryRole"];
            delete template["Resources"]["CWLFirehoseProcessor"];
            delete template["Resources"]["CWLFirehoseProcessorRole"];
            delete template["Resources"]["CWLFirehoseDeliveryPolicy"];
            delete template["Resources"]["CWLFirehoseDeliveryRole"];
            delete template["Resources"]["CWLFlowLogSubscriptionFilter"];
            delete template["Resources"]["CWLtoKinesisFirehoseRole"];
            delete template["Resources"]["CWLFirehoseDeliveryStream"];
        } else {
            // Grab the empty template section
            let subscription_filter_template = template["Resources"]["CWLFlowLogSubscriptionFilter"];

            // We are logging one or more CloudWatch logs. Set up template accordingly for each log group provided by the user
            for (let i=0; i<cwlGroups.length; i++) {
                let cwlGroup = cwlGroups[i];
                let cwlGroup_clean = "CWLFlowLogSubscriptionFilter" + (cwlGroup.toLowerCase()).split(' ').join('').replace(/\W/g, '');
                template["Resources"][cwlGroup_clean] = JSON.parse(JSON.stringify(subscription_filter_template));
                template["Resources"][cwlGroup_clean]["Properties"]["LogGroupName"] = cwlGroup;
            }
            // Delete the empty template section
            delete template["Resources"]["CWLFlowLogSubscriptionFilter"];

             // Add Splunk details
            template["Resources"]["CWLFirehoseDeliveryStream"]["Properties"]["SplunkDestinationConfiguration"]["HECEndpoint"] = HEC_ENDPOINT;
            if (!AUTO_HEC) {
                template["Resources"]["CWLFirehoseDeliveryStream"]["Properties"]["SplunkDestinationConfiguration"]["HECToken"] = HEC_TOKEN;
            } else {
                template["Resources"]["CWLFirehoseDeliveryStream"]["Properties"]["SplunkDestinationConfiguration"]["HECToken"] = AUTO_HEC_ACK_TOKEN;
            }
        }

        // CloudWatch Events
        /*
            CloudWatch Event object template:
                Note: source and detail-type will be replaced - there can be multiple detail-types to a single source

            Format:
                "CWEFindingEventRule": {
                  "Type": "AWS::Events::Rule",
                  "Properties": {
                      "EventPattern": {
                        "source": [],
                        "detail-type": []
                      },
                      "State": "ENABLED",
                      "Targets": [
                          {
                              "RoleArn": {
                                  "Fn::GetAtt": [
                                      "CWEFirehoseDeliveryRole",
                                      "Arn"
                                  ]
                              },
                              "Id": "splunk_cwe_firehose_target",
                              "Arn":  { "Fn::GetAtt" : [ "CWEFirehoseDeliveryStream", "Arn" ] }
                          }
                      ]
                  }
              },
         */
        if (!items[5].done) {
            // CloudWatch Event collection not selected. Delete all resources related only to CloudWatch log collection
            delete template["Resources"]["CWEFindingEventRule"];
        } else {
            // Grab the empty template section
            let cwe_rule_template = template["Resources"]["CWEFindingEventRule"];

            // Loop through cwe selections and add/populate a copy of the above template
            // One CloudFormation entry can have multiple event entries
            for (let i=0; i<cwe_event_type_selections.length; i++) {
                event = cwe_event_type_selections[i];
                let event_service = cwe_event_service_map[event];
                let event_rule_name = "CWEFindingEventRule" + (event_service.toLowerCase()).split('.').join('').replace(/\W/g, '');

                if (event_rule_name in template["Resources"]) {
                    // We have already created an entry for this event_rule_name
                    // Add the current event in the loop to the entry
                    template["Resources"][event_rule_name]["Properties"]["EventPattern"]["detail-type"].push(event);
                } else {
                    // Create a new entry for this event_rule_name based off of the cwe_rule_template
                    template["Resources"][event_rule_name] = JSON.parse(JSON.stringify(cwe_rule_template));
                    template["Resources"][event_rule_name]["Properties"]["EventPattern"]["source"].push(event_service);
                    template["Resources"][event_rule_name]["Properties"]["EventPattern"]["detail-type"].push(event);
                }

            }
            // Delete the empty template section
            delete template["Resources"]["CWEFindingEventRule"];

            // Add Splunk details
            template["Resources"]["CWEFirehoseDeliveryStream"]["Properties"]["SplunkDestinationConfiguration"]["HECEndpoint"] = HEC_ENDPOINT;
            if (!AUTO_HEC) {
                template["Resources"]["CWEFirehoseDeliveryStream"]["Properties"]["SplunkDestinationConfiguration"]["HECToken"] = HEC_TOKEN;
            } else {
                template["Resources"]["CWEFirehoseDeliveryStream"]["Properties"]["SplunkDestinationConfiguration"]["HECToken"] = AUTO_HEC_ACK_TOKEN;
            }
        }

        // All the below data options use the CWE Firehose
        if (!items[0].done && !items[2].done && !items[5].done) {
            // No selections use the CWE Firehose. Delete all resources related only to CWE Firehose
            delete template["Resources"]["CWEBackupS3Bucket"];
            delete template["Resources"]["CWEBackupS3Role"];
            delete template["Resources"]["CWEDeliveryRole"];
            delete template["Resources"]["CWEFirehoseProcessor"];
            delete template["Resources"]["CWEFirehoseProcessorRole"];
            delete template["Resources"]["CWEFirehoseDeliveryPolicy"];
            delete template["Resources"]["CWEFirehoseDeliveryRole"];
            delete template["Resources"]["CWEFirehoseDeliveryStream"];
        }

        // Create the CloudFormation template based off of user selections and previous configuration
        let textFile = null, makeTextFile = function (text) {
            let data = new Blob([text], {type: 'text/plain'});

            // If we are replacing a previously generated file we need to
            // manually revoke the object URL to avoid memory leaks.
            if (textFile !== null) {
              window.URL.revokeObjectURL(textFile);
            }

            textFile = window.URL.createObjectURL(data);

            return textFile;
        };

        let anchor = document.createElement('a');
        anchor.href = makeTextFile(JSON.stringify(template));
        anchor.target = '_blank';
        anchor.download = "customized_splunk_aws_template.json";
        anchor.click();

        if (macro) {
            // Create the CloudFormation template based off of user selections and previous configuration
            let macroTextFile = null, makeMacroTextFile = function (text) {
                let data = new Blob([text], {type: 'text/plain'});

                // If we are replacing a previously generated file we need to
                // manually revoke the object URL to avoid memory leaks.
                if (macroTextFile !== null) {
                    window.URL.revokeObjectURL(macroTextFile);
                }

                macroTextFile = window.URL.createObjectURL(data);

                return macroTextFile;
            };

            let macroAnchor = document.createElement('a');
            macroAnchor.href = makeMacroTextFile(JSON.stringify(macro_template));
            macroAnchor.target = '_blank';
            macroAnchor.download = "cloudwatch_log_groups_subscription_generator_macro_template.json";
            macroAnchor.click();
        }
    }
}

export default SplunkAwsConfigurationWebsite;
