# SplunkAwsConfigurationWebsite

Add all information required to get started with @splunk/splunk-aws-configuration-website here.
